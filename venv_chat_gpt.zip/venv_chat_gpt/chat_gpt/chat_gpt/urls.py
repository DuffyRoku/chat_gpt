
from django.contrib import admin
from django.urls import path
from django.urls import path, include
# from . import views

app_name = 'gpt'
urlpatterns = [
    path('admin/', admin.site.urls),
    path('', include('gpt.urls')),
    # path('', views.IndexView.as_view(),name="index"),
]
